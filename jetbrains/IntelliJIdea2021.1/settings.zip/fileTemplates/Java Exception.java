#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
public class ${NAME} extends RuntimeException {
    public ${NAME}(String message) {
        super(message);
    }

    public ${NAME}(String message, Exception cause) {
        super(message, cause);
    }
}
