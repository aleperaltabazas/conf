import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
#parse("File Header.java")
public class ${NAME} {
  ${BODY}
}