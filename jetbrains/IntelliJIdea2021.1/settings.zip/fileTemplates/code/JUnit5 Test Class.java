import static org.junit.jupiter.api.Assertions.*;
#parse("File Header.java")
class ${NAME} {
  ${BODY}
  
  @org.junit.jupiter.api.Test
  public void test() {
    assertTrue(true);
  }
}